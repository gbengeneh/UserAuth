import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<String> suits = Arrays.asList("♣️", "♦️", "♥️", "♠️");
        List<String> ranks = Arrays.asList("A","2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K");

        List<String> deck = new ArrayList<>();

     for (String suit : suits) {
          for (String rank : ranks) {
             deck.add(rank + suit);
           }
       }

        // this line Shuffle the deck
        Collections.shuffle(deck);

        // this line Sort the deck
        List<String> sortedDeck = sortDeck(deck);

        //defined the output statement Print sorted deck
        for (String card : sortedDeck) {
            System.out.print(card + " ");
        }
    }

    // function to sort Deck based on suit and create key for each suit and map the suit with the card using for loop and map
    public static List<String> sortDeck(List<String> deck) {
        Map<String, Integer> suitOrder = Map.of(
                "♣️", 0,
                "♦️", 1,
                "♥️", 2,
                "♠️", 3
        );

        Map<String, Integer> rankOrder = new HashMap<>();
        String[] rankList = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K","A"};
        for (int i = 0; i < rankList.length; i++) {
            rankOrder.put(rankList[i], i + 2);
        }

        deck.sort((card1, card2) -> {
            int[] key1 = getCardKey(card1, rankOrder, suitOrder);
            int[] key2 = getCardKey(card2, rankOrder, suitOrder);

            if (key1[0] != key2[0]) {
                return key1[0] - key2[0];
            }
            return key1[1] - key2[1];
        });

        return deck;
    }

    private static int[] getCardKey(String card, Map<String, Integer> rankOrder, Map<String, Integer> suitOrder) {
        for (String rank : rankOrder.keySet()) {
            if (card.startsWith(rank)) {
                String suit = card.substring(rank.length());
                return new int[]{suitOrder.getOrDefault(suit, -1), rankOrder.get(rank)};
            }
        }
        return new int[]{-1, -1}; // fallback
    }
}



