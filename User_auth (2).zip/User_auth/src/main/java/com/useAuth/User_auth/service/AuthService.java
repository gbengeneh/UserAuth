package com.useAuth.User_auth.service;

import com.useAuth.User_auth.dto.AuthRequest;
import com.useAuth.User_auth.model.UserEntity;
import com.useAuth.User_auth.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {
    private  final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthService(UserRepository userRepository, PasswordEncoder passwordEncoder){
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public String register(AuthRequest request){
        Optional<UserEntity> existingUser = userRepository.findByUsername(request.getUsername());
        if (existingUser.isPresent()){
            return "User Already Exist";
        }
        UserEntity userEntity = new UserEntity();
        userEntity.setUsername(request.getUsername());
        userEntity.setPassword(passwordEncoder.encode(request.getPassword()));
        userRepository.save(userEntity);
        return "User created successfully";
    }

    public String login(AuthRequest request){
        Optional<UserEntity> user =
                userRepository.findByUsername(request.getUsername());
        if(user.isPresent() && passwordEncoder.matches(request.getPassword(),
                user.get().getPassword())){
            return "Login successful";
        }
        return "invalid username or password";
    }

}
